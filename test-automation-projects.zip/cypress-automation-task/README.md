# Cypress Automated Tests – Vegetable Store

## 📌 Описание
Набор e2e тестов для сайта [Vegetable Store](https://rahulshettyacademy.com/seleniumPractise/#/), написанных на **Cypress (JavaScript)**.

## 🚀 Установка и запуск
```bash
npm install
npm run cypress:open
```
