const { test, expect } = require('@playwright/test');

test.describe("Vegetable Store Tests", () => {
  test("Search, add to cart and remove item", async ({ page }) => {
    await page.goto("https://rahulshettyacademy.com/seleniumPractise/#/");

    await page.fill(".search-keyword", "ro");

    const carrot = page.locator(".product").filter({ hasText: "Carrot" });
    await expect(carrot).toBeVisible();
    await carrot.locator("input.quantity").fill("5");

    const mushroom = page.locator(".product").filter({ hasText: "Mushroom" });
    await mushroom.locator(".increment").click();
    await mushroom.locator(".increment").click();

    await carrot.locator("button:has-text('ADD TO CART')").click();
    await mushroom.locator("button:has-text('ADD TO CART')").click();

    await page.click(".cart-icon");

    const cart = page.locator(".cart-preview");
    await expect(cart).toContainText("Carrot");
    await cart.locator("tr:has-text('Carrot') .product-remove").click();

    await expect(cart).not.toContainText("Carrot");
    await expect(cart).toContainText("Mushroom");
  });
});
