# Playwright Automated Tests – Vegetable Store

## 📌 Описание
E2E тесты для сайта [Vegetable Store](https://rahulshettyacademy.com/seleniumPractise/#/), написанные на **Playwright (JavaScript)**.

## 🚀 Установка и запуск
```bash
npm install
npx playwright install
npm test
```
